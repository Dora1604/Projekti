import SwiftUI

extension Font {
    static func avenirNext(size: Int) -> Font {
        return Font.custom("Avenir Next", size: CGFloat(size))
    }
    
    static func avenirNextRegular(size: Int) -> Font {
        return Font.custom("AvenirNext-Regular", size: CGFloat(size))
    }
}

struct RecommendView: View {
    var body: some View {
        ScrollView {
            GeometryReader { geometry in
                ImageCarouselView(numberOfImages: 3) {
                    Image("clarion")
                        .resizable()
                        .scaledToFill()
                        .frame(width: geometry.size.width, height: geometry.size.height)
                        .clipped()
                    Image("ordinary")
                        .resizable()
                        .scaledToFill()
                        .frame(width: geometry.size.width, height: geometry.size.height)
                        .clipped()
                    Image("corean")
                        .resizable()
                        .scaledToFill()
                        .frame(width: geometry.size.width, height: geometry.size.height)
                        .clipped()
                }
            }.frame(height: 300, alignment: .center)
            
            VStack(alignment: .leading, spacing: 10) {
                HStack {
                    Image("skincare")
                        .resizable()
                        .scaledToFill()
                        .frame(width: 55, height: 55)
                        .clipShape(Circle())
                        .shadow(radius: 4)
                    
                    VStack(alignment: .leading) {
                        Text("Best products for acne skin")
                            .font(.avenirNext(size: 12))
                            .foregroundColor(.gray)
                        Text("Showing 2 images of best skin exfoliators and one image how to use them.")
                            .font(.avenirNext(size: 17))
                    }
                }
                
                Text("Simple routine can change your skin forever")
                    .font(.avenirNextRegular(size: 12))
                    .foregroundColor(.gray)
                
                Text("In the old days, exfoliating your face was about as delicate a process as resurfacing your floors. But the newest generation of products lets you achieve clear, smooth skin without rubbing it raw.")
                    .font(.avenirNext(size: 28))
                
                Text("There are two kinds of exfoliators. Physical ones slough off dead skin cells using teeny-tiny grains or granules of some type, while chemical ones do it using face acids. Both will give you softer skin, lighten acne scars, and improve skin texture without making you red or creating wrinkles in the process.")
                    .lineLimit(nil)
                    .font(.avenirNextRegular(size: 17))
            }
            .padding(.horizontal)
            .padding(.top, 16.0)
        }.edgesIgnoringSafeArea(.all)
    }
}

struct RecommendView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
