//
//  Coordinator.swift
//  SkinRecognition
//
//  Created by Dora Franjic on 10/06/2020.
//  Copyright © 2020 Dora Franjic. All rights reserved.
//

import SwiftUI
import CoreML
import Vision
import ImageIO
class Coordinator: NSObject, UINavigationControllerDelegate, UIImagePickerControllerDelegate {
  @Binding var isCoordinatorShown: Bool
  @Binding var imageInCoordinator: Image?
  @Binding var classifier: String
  @Binding var model: SkinClassifier_1?
    
    init(isShown: Binding<Bool>, image: Binding<Image?>, classifier: Binding<String>, model:Binding<SkinClassifier_1?>) {
    _isCoordinatorShown = isShown
    _imageInCoordinator = image
    _classifier = classifier
    _model = model
        
  }

    
    func updateClassifications(for image: UIImage) {
     classifier = "Classifying..."
               DispatchQueue.global(qos: .userInitiated).async {
                   
                   let inputImageSize: CGFloat = 229.0
                   let minLen = min(image.size.width, image.size.height)
                   let resizedImage = image.resize(to: CGSize(width: inputImageSize * image.size.width / minLen, height: inputImageSize * image.size.height / minLen))
                   let cropedToSquareImage = resizedImage.cropToSquare()

                   guard let pixelBuffer = cropedToSquareImage?.pixelBuffer() else {
                       fatalError()
                   }
                    let myModel = SkinClassifier_1()
                   guard let classifierOutput = try? myModel.prediction(image: pixelBuffer) else {
                       fatalError()
                   }

                   DispatchQueue.main.async {
                    self.classifier = classifierOutput.classLabel
                    print(self.classifier)
                   }
               }
           }
 
     
        
    
  func imagePickerController(_ picker: UIImagePickerController,
                didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
  
           //picker.dismiss(animated: true)
          guard let unwrapImage = info[UIImagePickerController.InfoKey.originalImage] as? UIImage else { return }
  
             imageInCoordinator = Image(uiImage: unwrapImage)
             isCoordinatorShown = false
             updateClassifications(for: unwrapImage)
    
          }
        
  func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
     isCoordinatorShown = false
  }
}
