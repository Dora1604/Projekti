//
//  ContentView.swift
//  SkinRecognition
//
//  Created by Dora Franjic on 09/06/2020.
//  Copyright © 2020 Dora Franjic. All rights reserved.
//

import SwiftUI
import CoreML
import Vision
import ImageIO

struct ContentView: View {
    @State var model:SkinClassifier_1? = SkinClassifier_1()
    @State var classifier: String = ""
    @State var image: Image? = nil
    @State var showCaptureImageView: Bool = false
    @State var showCaptureCameraView: Bool = false
    @State var nextView: Bool = false
    //self.setNeedsDisplay()
   
   
   var body: some View {
    VStack(spacing:50) {
            HStack(spacing: 230) {
         Button(action: {
            
           self.showCaptureImageView.toggle()
         }) {
             Image(systemName: "folder")
                 .font(.largeTitle)
                .foregroundColor(.black)
         }
         
        Button(action: {
           
          self.showCaptureCameraView.toggle()
        }) {
            Image(systemName: "camera")
             .font(.largeTitle)
            .foregroundColor(.black)
          
                } }
        if self.classifier == "" {
            Text("Hi! This app will help you diagnose your skin problems. Please take a photo of your problematic area or choose one from your gallery.").fontWeight(.light).multilineTextAlignment(.center)
            .padding(.leading,50)
            .padding(.trailing,50)
                .foregroundColor(.black)
        } else {
            Text("Your result is listed below. Acne means you have acne or pimple problems, and ClearSkin means that most of your face is cleared from skin problems.").fontWeight(.light).multilineTextAlignment(.center)
                .padding(.leading,50)
                .padding(.trailing,50)
                .foregroundColor(.black)
                


        }
        Text(self.classifier)
        .fontWeight(.semibold)
            .foregroundColor(Color.black)
        //.foregroundColor(.white)
        //.font(.caption)
         .font(.system(size:20))
            .cornerRadius(10)
        
        if self.classifier=="" || self.classifier=="ClearSkin" { } else {
        Button(action: {
           
          self.nextView.toggle()
        }) {
            Text("Show me solutions").fontWeight(.light).foregroundColor(Color.black)
        }.sheet(isPresented: $nextView) {
                RecommendView()
                
        } }

        
         image?.resizable()
           .frame(width: 250, height: 200)
           .clipShape(RoundedRectangle(cornerRadius: 20))
           .overlay(RoundedRectangle(cornerRadius: 20).stroke(Color.black, lineWidth: 4))
          .animation(.easeIn)
           //.shadow(radius: 10)
        
        
     
      
        
      

        
       if (showCaptureImageView) {
        CaptureImageView(isShown: $showCaptureImageView, image: $image, classifier: $classifier, model:$model).onAppear {
            //print(self.classifier)
        }
        
       }
        if (showCaptureCameraView) {
            CaptureCameraView(isShown: $showCaptureCameraView, image: $image, classifier: $classifier, model:$model).onAppear {
                //print(self.classifier)
            }
            
        }
       
    }.frame(minWidth: 0, maxWidth: .infinity, minHeight: 0, maxHeight: .infinity, alignment: .top).padding(.top,80).background(Image("background").resizable().opacity(0.9))
     .edgesIgnoringSafeArea(.all)
    }
   



}


struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
            .padding()
    }
}
