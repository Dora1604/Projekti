//
//  CaptureImageView.swift
//  SkinRecognition
//
//  Created by Dora Franjic on 10/06/2020.
//  Copyright © 2020 Dora Franjic. All rights reserved.
//
import SwiftUI
import ImageIO
import UIKit
struct CaptureImageView {
    @Binding var isShown: Bool
     @Binding var image: Image?
    @Binding var classifier: String
    @Binding var model: SkinClassifier_1?
     
     func makeCoordinator() -> Coordinator {
     return Coordinator(isShown: $isShown, image: $image, classifier:$classifier, model:$model)
         }
  /// TODO 2: Implement other things later
}
extension CaptureImageView: UIViewControllerRepresentable {
    func makeUIViewController(context: UIViewControllerRepresentableContext<CaptureImageView>) -> UIImagePickerController {
        let picker = UIImagePickerController()
        picker.delegate = context.coordinator
        picker.sourceType = .photoLibrary
        return picker
    }
   
    func updateUIViewController(_ uiViewController: UIImagePickerController,
                                context: UIViewControllerRepresentableContext<CaptureImageView>) {
        
    }
}
